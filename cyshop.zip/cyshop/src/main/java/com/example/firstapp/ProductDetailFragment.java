package com.example.firstapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProductDetailFragment extends Fragment {

    private TextView textViewName;
    private TextView textViewPrice;
    private ImageView imageViewProduct;
    private TextView textViewNum;
    private EditText editTextQuantity;
    private Button buttonAddToCart;


    private String productName;
    private double productPrice;
    private int imageResId;
    private int num;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_product_detail, container, false);

        textViewName = view.findViewById(R.id.textViewName);
        textViewPrice = view.findViewById(R.id.textViewPrice);
        imageViewProduct = view.findViewById(R.id.imageViewProduct);
        textViewNum = view.findViewById(R.id.textViewNum);
        editTextQuantity = view.findViewById(R.id.editTextQuantity);
        buttonAddToCart = view.findViewById(R.id.buttonAddToCart);

        Bundle bundle = getArguments();
        if (bundle != null) {
            productName = bundle.getString("productName");
            productPrice = bundle.getDouble("productPrice");
            imageResId = bundle.getInt("imageResId");
            num = bundle.getInt("num");

            textViewName.setText(productName);
            textViewPrice.setText(String.valueOf(productPrice));
            imageViewProduct.setImageResource(imageResId);
            textViewNum.setText("Stock: " + num);
        }

        if (num == 0) {
            buttonAddToCart.setEnabled(false);
        }

        buttonAddToCart.setOnClickListener(view1 -> {
            String quantityStr = editTextQuantity.getText().toString();
            int quantity = Integer.parseInt(quantityStr);

            if (quantity <= num) {
                Product product = new Product(productName, productPrice, 0, imageResId,num);
                Cart.getInstance().addProduct(product);
                num -= quantity;
                textViewNum.setText("Stock: " + num);
                if (num == 0) {
                    buttonAddToCart.setEnabled(false);
                }
            } else {
                // 显示库存不足的提示
                Toast.makeText(getContext(), "Stock insufficient", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
