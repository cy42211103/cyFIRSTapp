package com.example.firstapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private GridView gridView;
    private List<Product> products;
    private Button buttonViewCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.gridView);
        buttonViewCart = findViewById(R.id.buttonViewCart);
        products = ProductData.products;

        ProductAdapter productAdapter = new ProductAdapter(this, products);
        gridView.setAdapter(productAdapter);

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            Product selectedProduct = products.get(position);

            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("加入购物车")
                    .setMessage("是否将 " + selectedProduct.getName() + " 添加到购物车？")
                    .setPositiveButton("是", (dialog, which) -> {
                        // 检查库存并添加到购物车
                        if (selectedProduct.getNum() >= 1) {
                            Cart.getInstance().addProduct(selectedProduct);
                        }

                        selectedProduct.reduceStockQuantity(1, MainActivity.this);

                        // 通知适配器数据已更改以刷新视图
                        productAdapter.notifyDataSetChanged();
                    })
                    .setNegativeButton("否", null)
                    .show();

            Bundle bundle = new Bundle();
            bundle.putString("productName", selectedProduct.getName());
            bundle.putDouble("productPrice", selectedProduct.getPrice());
            bundle.putInt("imageResId", selectedProduct.getImageResId());

            ProductDetailFragment productDetailFragment = new ProductDetailFragment();
            productDetailFragment.setArguments(bundle);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, productDetailFragment)
                    .addToBackStack(null)
                    .commit();
        });

        buttonViewCart.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CartActivity.class);
            startActivity(intent);
        });

    }
}
