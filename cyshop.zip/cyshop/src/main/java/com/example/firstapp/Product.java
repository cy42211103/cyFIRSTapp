package com.example.firstapp;

import android.content.Context;
import android.widget.Toast;

public class Product {
    private String name;
    private double price;
    private int column;
    private int imageResId;
    private int num;

    public Product(String name, double price, int column, int imageResId,int num) {
        this.name = name;
        this.price = price;
        this.column = column;
        this.imageResId = imageResId;
        this.num=num;

    }

    public void reduceStockQuantity(int amount, Context context) {
        if (this.num >= amount) {
            this.num -=amount ;
        } else {
            Toast.makeText(context,"商品余量不足",Toast.LENGTH_SHORT).show();

        }
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getColumn() {
        return column;
    }

    public int getImageResId() {
        return imageResId;
    }
    public int getNum(){
        return num;
    }


}
