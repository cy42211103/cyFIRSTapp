package com.example.firstapp;

import java.util.ArrayList;
import java.util.List;

public class ProductData {

    public static List<Product> products = new ArrayList<>();

    static {
        products.add(new Product("商品1", 10.99, 1, R.drawable.a,4));
        products.add(new Product("商品2", 20.99, 1, R.drawable.b,3));
        products.add(new Product("商品3", 15.99, 1, R.drawable.c,5));
        products.add(new Product("商品4", 25.99, 1, R.drawable.d,6));
        products.add(new Product("商品5", 12.99, 1, R.drawable.e,7));
        products.add(new Product("商品6", 55.99, 1, R.drawable.f,113));
        products.add(new Product("商品7", 102.99, 1, R.drawable.g,20));
        products.add(new Product("商品8", 100.99, 1, R.drawable.h,300));
        products.add(new Product("商品9", 9.99, 1, R.drawable.i,4));
        products.add(new Product("商品10", 1.99, 1, R.drawable.j,6));
    }


}
