package com.example.firstapp;

import static com.example.firstapp.ProductData.products;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ProductAdapter extends BaseAdapter {

    private Context context;
    private List<Product> productList;

    public ProductAdapter(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
    }

    @Override
    public int getCount() {
        return productList.size();
    }

    @Override
    public Object getItem(int position) {
        return productList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
            holder = new ViewHolder();
            holder.imageViewProduct = convertView.findViewById(R.id.imageViewProduct);
            holder.textViewName = convertView.findViewById(R.id.textViewName);
            holder.textViewPrice = convertView.findViewById(R.id.textViewPrice);
            holder.textViewnum= convertView.findViewById(R.id.textViewNum);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Product product = products.get(position);
        holder.imageViewProduct.setImageResource(product.getImageResId());
        holder.textViewName.setText(product.getName());
        holder.textViewPrice.setText("￥" + product.getPrice());
        holder.textViewnum.setText(product.getNum()+"个");

        return convertView;
    }

    private static class ViewHolder {
        ImageView imageViewProduct;
        TextView textViewName;
        TextView textViewPrice;
        TextView textViewnum;
    }

}
