package com.example.firstapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class CartActivity extends AppCompatActivity {

    private ListView listViewCart;
    private List<Product> cartProducts;
    private TextView textViewTotalPrice;
    private Button buttonCheckout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        listViewCart = findViewById(R.id.listViewCart);
        textViewTotalPrice = findViewById(R.id.textViewTotalPrice);
        buttonCheckout = findViewById(R.id.buttonCheckout);

        cartProducts = Cart.getInstance().getProducts();

        CartAdapter cartAdapter = new CartAdapter(this, cartProducts);
        listViewCart.setAdapter(cartAdapter);

        updateTotalPrice();

        buttonCheckout.setOnClickListener(view -> {

            Cart.getInstance().clearCart();
            updateTotalPrice();

        });
    }

    private void updateTotalPrice() {
        double total = 0;
        for (Product product : cartProducts) {
            total += product.getPrice();
        }
        textViewTotalPrice.setText("总金额: ￥" + total);
    }
}
