package com.example.firstapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DBHelper(this);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        TextView textViewRegister = findViewById(R.id.textViewRegister);

        buttonLogin.setOnClickListener(view -> {
            String username = editTextUsername.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            new LoginTask().execute(username, password);
        });

        textViewRegister.setOnClickListener(view -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    private class LoginTask extends AsyncTask<String, Void, Boolean> {

        @Override
        protected Boolean doInBackground(String... params) {
            String username = params[0];
            String password = params[1];

            return authenticate(username, password);
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(LoginActivity.this, "错误的密码或用户名", Toast.LENGTH_SHORT).show();
            }
        }

        private Boolean authenticate(String username, String password) {
            // Hardcoding initial username and password
            String initialUsername = "admin";
            String initialPassword = "123";

            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.query(
                    DBHelper.TABLE_USER,
                    new String[]{DBHelper.COLUMN_USERNAME, DBHelper.COLUMN_PASSWORD},
                    DBHelper.COLUMN_USERNAME + "=? AND " + DBHelper.COLUMN_PASSWORD + "=?",
                    new String[]{username, password},
                    null,
                    null,
                    null
            );

            boolean isRegisteredUser = cursor.getCount() > 0;
            cursor.close();
            db.close();

            // Check if the provided username and password match the initial username and password
            boolean isInitialUser = username.equals(initialUsername) && password.equals(initialPassword);

            // Return true if either the user is a registered user or matches the initial username and password
            return isRegisteredUser || isInitialUser;
        }
    }
}