package com.example.firstapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class CartAdapter extends BaseAdapter {

    private Context context;
    private List<Product> productList;

    public CartAdapter(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
    }

    @Override
    public int getCount() {
        return productList.size();
    }

    @Override
    public Object getItem(int position) {
        return productList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
            holder = new ViewHolder();
            holder.imageViewProduct = convertView.findViewById(R.id.imageViewProduct);
            holder.textViewName = convertView.findViewById(R.id.textViewName);
            holder.textViewPrice = convertView.findViewById(R.id.textViewPrice);
            holder.textViewQuantity = convertView.findViewById(R.id.textViewQuantity);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Product cartProduct = productList.get(position);
        Product product= cartProduct;


        holder.imageViewProduct.setImageResource(product.getImageResId());
        holder.textViewName.setText(product.getName());
        holder.textViewPrice.setText("￥" + product.getPrice());


        return convertView;
    }

    private static class ViewHolder {
        ImageView imageViewProduct;
        TextView textViewName;
        TextView textViewPrice;
        TextView textViewQuantity;
    }
}
